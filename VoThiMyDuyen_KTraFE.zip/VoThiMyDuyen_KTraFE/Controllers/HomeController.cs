﻿using System.Web.Mvc;

namespace VoThiMyDuyen_KtraFE.Controllers
{
    public class HomeController : Controller
    {
      
        public ActionResult Index()
        {
            
            return View();
        }
    }
}