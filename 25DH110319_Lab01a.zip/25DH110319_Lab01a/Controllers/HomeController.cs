﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _25DH110319_Lab01a.Controllers
{
        public class HomeController : Controller
        {
            // Trang mặc định (Index)
            public ActionResult Index()
            {
                return View();
            }

            // Action cho Bài 1
            public ActionResult Lab01a()
            {
                return View();
            }

            // Action cho Bài 2
            public ActionResult Lab01b()
            {
                return View();
            }

            // Action cho Bài 3
            public ActionResult Lab01c()
            {
                return View();
            }
        }
    }
