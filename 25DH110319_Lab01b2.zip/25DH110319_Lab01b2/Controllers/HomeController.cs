﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _25DH110319_Lab01b2.Controllers
{
    public class HomeController : Controller
    {
        // Tuần 02 - Bài 1
        public ActionResult Lab02_Bai1() { return View(); }

        // Tuần 02 - Bài 2 (Layout bằng Table)
        public ActionResult Lab02_Bai2() { return View(); }

        // Tuần 02 - Bài 3 (Layout bằng DIV)
        public ActionResult Lab02_Bai3() { return View(); }

        // Tuần 02 - Bài 4 (Layout bằng thẻ HTML5)
        public ActionResult Lab02_Bai4() { return View(); }
    }
}