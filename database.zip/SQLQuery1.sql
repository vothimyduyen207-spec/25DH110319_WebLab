USE MyStore;
GO

-- Xem ảnh hiện tại trong DB
SELECT ProductID, ProductName, ProductImage FROM Product;

-- 1. Danh mục (chỉ thêm khi chưa có)
INSERT INTO Category (CategoryName)
SELECT v.Name FROM (VALUES (N'Điện thoại'), (N'Laptop'), (N'Phụ kiện')) AS v(Name)
WHERE NOT EXISTS (SELECT 1 FROM Category c WHERE c.CategoryName = v.Name);

-- 2. Sản phẩm + ảnh riêng cho từng sản phẩm (cột cuối = tên file trong Content/images)
-- Dữ liệu mẫu: mỗi dòng gồm Danh mục, Tên, Mô tả, Giá, Tên file ảnh
SELECT * INTO #SP FROM (VALUES
    (N'Điện thoại', N'iPhone 15 Pro Max',    N'Màn hình 6.7 inch, chip A17 Pro, camera 48MP',     29990000, N'ip.jpg'),
    (N'Điện thoại', N'Samsung Galaxy S24',   N'Màn hình Dynamic AMOLED 6.2 inch, camera 50MP',     19990000, N'ss.jpg'),
    (N'Điện thoại', N'Xiaomi 14',            N'Snapdragon 8 Gen 3, sạc nhanh 90W',                 15990000, N'xiaomi.jpg'),
    (N'Laptop',     N'MacBook Air M2',       N'Chip M2, màn hình 13.6 inch, pin 18 giờ',           27990000, N'macbook.jpg'),
    (N'Laptop',     N'Dell XPS 13',          N'Core i7, RAM 16GB, SSD 512GB, màn hình 13.4 inch',  32990000, N'dell.jpg'),
    (N'Laptop',     N'Asus ROG Strix G16',   N'Core i9, RTX 4060, màn hình 165Hz',                 35990000, N'asus.jpg'),
    (N'Phụ kiện',   N'Tai nghe AirPods Pro', N'Chống ồn chủ động, sạc không dây',                  5990000,  N'tainghe.jpg'),
    (N'Phụ kiện',   N'Sạc nhanh Anker 65W',  N'Sạc nhanh 3 cổng, nhỏ gọn',                         890000,   N'anker.jpg'),
    (N'Phụ kiện',   N'Chuột Logitech MX',    N'Chuột không dây, 8 nút, pin 70 ngày',               1990000,  N'logitech.jpg')
) AS t(CatName, Name, Descr, Price, ImgFile);

-- Thêm sản phẩm chưa có
INSERT INTO Product (CategoryID, ProductName, ProductDecription, ProductPrice, ProductImage)
SELECT c.CategoryID, s.Name, s.Descr, s.Price, N'~/Content/images/' + s.ImgFile
FROM #SP s
JOIN Category c ON c.CategoryName = s.CatName
WHERE NOT EXISTS (SELECT 1 FROM Product x WHERE x.ProductName = s.Name);

-- 3. Cập nhật ảnh riêng cho từng sản phẩm (cả sản phẩm đã có từ lần chạy trước)
UPDATE p
SET p.ProductImage = N'~/Content/images/' + s.ImgFile
FROM Product p
JOIN #SP s ON s.Name = p.ProductName;

DROP TABLE #SP;

-- 4. Kiểm tra lại
SELECT c.CategoryName, p.ProductName, p.ProductPrice, p.ProductImage
FROM Product p JOIN Category c ON c.CategoryID = p.CategoryID;