﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Web;

namespace BE_VoThiMyDuyen_25DH110319.Models
{
    public partial class Product
    {
        [NotMapped]
        public HttpPostedFileBase UploadImg { get; set; }
    }
}