﻿using System.Collections.Generic;
using PagedList;

namespace BE_VoThiMyDuyen_25DH110319.Models.ViewModel
{
    public class HomeProductVM
    {
        public string SearchTerm { get; set; }
        public List<Product> FeaturedProducts { get; set; }
        public IPagedList<Product> NewProducts { get; set; }
    }
}