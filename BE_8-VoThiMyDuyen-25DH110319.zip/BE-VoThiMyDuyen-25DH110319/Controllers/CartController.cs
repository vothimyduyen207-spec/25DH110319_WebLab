﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Controllers
{
    public class CartController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public List<CartItem> GetCart()
        {
            List<CartItem> myCart = Session["Cart"] as List<CartItem>;
            if (myCart == null)
            {
                myCart = new List<CartItem>();
                Session["Cart"] = myCart;
            }
            return myCart;
        }

        public ActionResult AddToCart(int id, string strURL)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return RedirectToAction("Index", "Home");
            }

            List<CartItem> myCart = GetCart();
            CartItem item = myCart.Find(p => p.iProductID == id);

            if (item == null)
            {
                item = new CartItem(id);
                myCart.Add(item);
            }
            else
            {
                item.iQuantity++;
            }

            if (string.IsNullOrEmpty(strURL))
            {
                return RedirectToAction("Index", "Cart");
            }
            return Redirect(strURL);
        }

        private int TotalQuantity()
        {
            List<CartItem> myCart = Session["Cart"] as List<CartItem>;
            if (myCart == null) return 0;
            return myCart.Sum(p => p.iQuantity);
        }

        private decimal TotalPrice()
        {
            List<CartItem> myCart = Session["Cart"] as List<CartItem>;
            if (myCart == null) return 0;
            return myCart.Sum(p => p.dTotalPrice);
        }

        public ActionResult Index()
        {
            List<CartItem> myCart = GetCart();
            if (myCart.Count == 0)
            {
                ViewBag.Notification = "Giỏ hàng của bạn đang trống!";
            }

            ViewBag.TotalQuantity = TotalQuantity();
            ViewBag.TotalPrice = TotalPrice();

            return View(myCart);
        }

        public ActionResult RemoveCartItem(int id)
        {
            List<CartItem> myCart = GetCart();
            CartItem item = myCart.SingleOrDefault(n => n.iProductID == id);
            if (item != null)
            {
                myCart.RemoveAll(n => n.iProductID == id);
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult UpdateCart(int id, FormCollection form)
        {
            List<CartItem> myCart = GetCart();
            CartItem item = myCart.SingleOrDefault(n => n.iProductID == id);
            if (item != null)
            {
                if (int.TryParse(form["txtQuantity"], out int q))
                {
                    if (q <= 0)
                    {
                        myCart.RemoveAll(n => n.iProductID == id);
                    }
                    else
                    {
                        item.iQuantity = q;
                    }
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult CartPartial()
        {
            ViewBag.TotalQuantity = TotalQuantity();
            return PartialView();
        }

        public ActionResult Checkout()
        {
            List<CartItem> myCart = GetCart();
            if (myCart == null || myCart.Count == 0)
            {
                return RedirectToAction("Index", "Home");
            }

            Customer customer = Session["Customer"] as Customer;
            if (customer == null)
            {
                string username = Session["Username"] as string ?? (User.Identity.IsAuthenticated ? User.Identity.Name : null);
                if (!string.IsNullOrEmpty(username))
                {
                    customer = db.Customers.FirstOrDefault(c => c.Username == username);
                    if (customer != null) Session["Customer"] = customer;
                }
            }

            if (customer == null)
            {
                return RedirectToAction("Login", "Account", new { returnUrl = Url.Action("Checkout", "Cart") });
            }

            ViewBag.Customer = customer;
            ViewBag.TotalQuantity = TotalQuantity();
            ViewBag.TotalPrice = TotalPrice();

            return View(myCart);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Checkout(FormCollection form)
        {
            try
            {
                List<CartItem> myCart = GetCart();
                if (myCart == null || myCart.Count == 0)
                {
                    return RedirectToAction("Index", "Home");
                }

                Customer customer = Session["Customer"] as Customer;
                if (customer == null)
                {
                    string username = Session["Username"] as string ?? (User.Identity.IsAuthenticated ? User.Identity.Name : null);
                    if (!string.IsNullOrEmpty(username))
                    {
                        customer = db.Customers.FirstOrDefault(c => c.Username == username);
                        if (customer != null) Session["Customer"] = customer;
                    }
                }

                if (customer == null)
                {
                    return RedirectToAction("Login", "Account", new { returnUrl = Url.Action("Checkout", "Cart") });
                }

                string address = form["AddressDelivery"];
                if (string.IsNullOrWhiteSpace(address))
                {
                    ViewBag.Error = "Vui lòng nhập địa chỉ nhận hàng!";
                    ViewBag.Customer = customer;
                    ViewBag.TotalQuantity = TotalQuantity();
                    ViewBag.TotalPrice = TotalPrice();
                    return View(myCart);
                }

                Order order = new Order();
                order.OrderDate = DateTime.Now;
                order.AddressDelivery = address.Trim();
                order.CustomerID = customer.CustomerID;
                order.TotalAmount = myCart.Sum(i => i.dTotalPrice);
                // Theo đúng yêu cầu của cô: Tạo đơn -> Chờ xử lý / COD (Chưa thanh toán)
                order.PaymentStatus = "COD (Chưa thanh toán)";

                db.Orders.Add(order);
                db.SaveChanges();

                foreach (var item in myCart)
                {
                    OrderDetail detail = new OrderDetail();
                    detail.OrderID = order.OrderID;
                    detail.ProductID = item.iProductID;
                    detail.Quantity = item.iQuantity;
                    detail.UnitPrice = item.dPrice;

                    db.OrderDetails.Add(detail);
                }
                db.SaveChanges();

                Session["Cart"] = null;

                return RedirectToAction("OrderSuccess");
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Có lỗi xảy ra trong quá trình xử lý đơn hàng: " + ex.Message;
                return View(GetCart());
            }
        }

        public ActionResult OrderSuccess()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}