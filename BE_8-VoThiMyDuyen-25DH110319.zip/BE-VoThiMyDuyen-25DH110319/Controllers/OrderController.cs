﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Controllers
{
    public class OrderController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        private Customer GetCurrentCustomer()
        {
            if (Session["Customer"] != null)
            {
                return Session["Customer"] as Customer;
            }

            string username = Session["Username"] as string ?? (User.Identity.IsAuthenticated ? User.Identity.Name : null);
            if (!string.IsNullOrEmpty(username))
            {
                var customer = db.Customers.SingleOrDefault(c => c.Username == username);
                if (customer != null)
                {
                    Session["Customer"] = customer;
                    return customer;
                }
            }
            return null;
        }

        // Tra cuu lich su mua hang
        public ActionResult OrderHistory()
        {
            var customer = GetCurrentCustomer();
            if (customer == null)
            {
                return RedirectToAction("Login", "Account", new { returnUrl = Url.Action("OrderHistory", "Order") });
            }

            var orders = db.Orders
                .Include(o => o.OrderDetails.Select(od => od.Product))
                .Where(o => o.CustomerID == customer.CustomerID)
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            return View(orders);
        }

        // MyOrder alias
        public ActionResult MyOrder()
        {
            return RedirectToAction("OrderHistory");
        }

        // Chi tiet don hang
        public ActionResult OrderDetail(int id)
        {
            var customer = GetCurrentCustomer();
            if (customer == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var order = db.Orders
                .Include(o => o.OrderDetails.Select(od => od.Product))
                .SingleOrDefault(o => o.OrderID == id && o.CustomerID == customer.CustomerID);

            if (order == null)
            {
                return HttpNotFound();
            }

            return View(order);
        }

        public ActionResult Checkout()
        {
            return RedirectToAction("Checkout", "Cart");
        }

        public ActionResult OrderSuccess()
        {
            return RedirectToAction("OrderSuccess", "Cart");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}