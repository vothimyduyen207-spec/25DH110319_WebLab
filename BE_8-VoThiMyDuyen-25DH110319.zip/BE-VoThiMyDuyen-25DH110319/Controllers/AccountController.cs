﻿using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using BE_VoThiMyDuyen_25DH110319.Models;
using BE_VoThiMyDuyen_25DH110319.Models.ViewModel;

using UserEntity = BE_VoThiMyDuyen_25DH110319.Models.User;

namespace BE_VoThiMyDuyen_25DH110319.Controllers
{
    public class AccountController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        // ---------- ĐĂNG KÝ ----------//
        [HttpGet]
        public ActionResult Register()
        {
            return View(new RegisterVM());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Register(RegisterVM model)
        {
            if (!ModelState.IsValid) return View(model);

            // Kiểm tra thêm trùng (Username & Email)
            if (db.Users.Any(u => u.Username.ToLower() == model.Username.Trim().ToLower()))
            {
                ModelState.AddModelError("Username", "Tên đăng nhập này đã tồn tại trong hệ thống!");
                return View(model);
            }

            if (db.Customers.Any(c => c.CustomerEmail.ToLower() == model.Email.Trim().ToLower()))
            {
                ModelState.AddModelError("Email", "Email này đã được đăng ký bởi tài khoản khác!");
                return View(model);
            }

            var user = new UserEntity
            {
                Username = model.Username.Trim(),
                Password = model.Password,
                UserRole = "C" // Customer role (NCHAR(1))
            };

            var customer = new Customer
            {
                CustomerName = model.CustomerName.Trim(),
                CustomerPhone = model.Phone.Trim(),
                CustomerEmail = model.Email.Trim(),
                CustomerAddress = model.Address.Trim(),
                Username = model.Username.Trim()
            };

            try
            {
                db.Users.Add(user);
                db.Customers.Add(customer);
                db.SaveChanges();

                // Đăng nhập tự động sau khi đăng ký
                Session["Username"] = user.Username;
                Session["UserRole"] = user.UserRole;
                Session["Customer"] = customer;
                FormsAuthentication.SetAuthCookie(user.Username, false);
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                foreach (var entity in ex.EntityValidationErrors)
                    foreach (var err in entity.ValidationErrors)
                        ModelState.AddModelError("", err.PropertyName + ": " + err.ErrorMessage);
                return View(model);
            }
            catch (System.Exception ex)
            {
                var inner = ex;
                while (inner.InnerException != null) inner = inner.InnerException;
                ModelState.AddModelError("", "Lỗi lưu dữ liệu: " + inner.Message);
                return View(model);
            }

            return RedirectToAction("Index", "Home");
        }

        // ---------- ĐĂNG NHẬP ----------//
        [HttpGet]
        public ActionResult Login()
        {
            return View(new LoginVM());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(LoginVM model, string returnUrl)
        {
            if (!ModelState.IsValid) return View(model);

            // ===== MỚI: kiểm tra bảng AdminAccount trước =====
            var admin = db.AdminAccounts.FirstOrDefault(a =>
                a.AdminUsername == model.Username && a.AdminPassword == model.Password);

            if (admin != null)
            {
                Session["Admin"] = admin;
                Session["Username"] = admin.AdminUsername;
                Session["UserRole"] = "A";
                Session["Customer"] = null;
                FormsAuthentication.SetAuthCookie(admin.AdminUsername, model.RememberMe);
                return RedirectToAction("Index", "Home", new { area = "Admin" });
            }
            // ===== HẾT PHẦN MỚI =====

            var user = db.Users.SingleOrDefault(u =>
                u.Username == model.Username && u.Password == model.Password);

            if (user == null)
            {
                ModelState.AddModelError("", "Tên đăng nhập hoặc mật khẩu không đúng");
                return View(model);
            }

            Session["Username"] = user.Username;
            Session["UserRole"] = user.UserRole;
            Session["Customer"] = db.Customers.FirstOrDefault(c => c.Username == user.Username);
            FormsAuthentication.SetAuthCookie(user.Username, model.RememberMe);

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            // Nếu là Admin thì có thể chuyển hướng hoặc về trang chủ
            if (user.UserRole == "A")
            {
                return RedirectToAction("Index", "Home", new { area = "Admin" });
            }

            return RedirectToAction("Index", "Home");
        }

        // ---------- ĐĂNG XUẤT ----------//
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        // ---------- THÔNG TIN & CHỈNH SỬA TÀI KHOẢN ----------//
        [HttpGet]
        public ActionResult ProfileInfo()
        {
            string username = Session["Username"] as string ?? (User.Identity.IsAuthenticated ? User.Identity.Name : null);
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login", new { returnUrl = Url.Action("ProfileInfo") });
            }

            var customer = db.Customers.SingleOrDefault(c => c.Username == username);
            if (customer == null)
            {
                return HttpNotFound();
            }

            return View(customer);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult ProfileInfo(Customer model)
        {
            string username = Session["Username"] as string ?? (User.Identity.IsAuthenticated ? User.Identity.Name : null);
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Login", new { returnUrl = Url.Action("ProfileInfo") });
            }

            var customer = db.Customers.SingleOrDefault(c => c.Username == username);
            if (customer == null)
            {
                return HttpNotFound();
            }

            if (string.IsNullOrWhiteSpace(model.CustomerName))
            {
                ModelState.AddModelError("CustomerName", "Họ tên không được để trống!");
            }
            if (string.IsNullOrWhiteSpace(model.CustomerPhone))
            {
                ModelState.AddModelError("CustomerPhone", "Số điện thoại không được để trống!");
            }
            if (string.IsNullOrWhiteSpace(model.CustomerEmail))
            {
                ModelState.AddModelError("CustomerEmail", "Email không được để trống!");
            }

            // Kiểm tra trùng email với tài khoản khác
            if (db.Customers.Any(c => c.CustomerID != customer.CustomerID && c.CustomerEmail.ToLower() == model.CustomerEmail.Trim().ToLower()))
            {
                ModelState.AddModelError("CustomerEmail", "Email này đã được sử dụng bởi khách hàng khác!");
            }

            if (ModelState.IsValid)
            {
                customer.CustomerName = model.CustomerName.Trim();
                customer.CustomerPhone = model.CustomerPhone.Trim();
                customer.CustomerEmail = model.CustomerEmail.Trim();
                customer.CustomerAddress = (model.CustomerAddress ?? "").Trim();

                db.SaveChanges();
                Session["Customer"] = customer;
                ViewBag.Success = "Cập nhật thông tin tài khoản thành công!";
            }

            return View(customer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}