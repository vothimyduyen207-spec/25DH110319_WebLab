﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers;
using BE_VoThiMyDuyen_25DH110319.Models;
using BE_VoThiMyDuyen_25DH110319.Models.ViewModel;
using PagedList;

namespace BE_VoThiMyDuyen_25DH110319.Controllers
{
    public class HomeController :Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public ActionResult Index(string searchTerm, int? page)
        {
            var model = new HomeProductVM();
            var products = db.Products.AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                model.SearchTerm = searchTerm;
                products = products.Where(p =>
                    p.ProductName.Contains(searchTerm) ||
                    p.ProductDecription.Contains(searchTerm) ||
                    p.Category.CategoryName.Contains(searchTerm));
            }

            int pageNumber = page ?? 1;
            int pageSize = 6;

            model.FeaturedProducts = products
                .OrderByDescending(p => p.OrderDetails.Sum(od => (int?)od.Quantity) ?? 0)
                .Take(10)
                .ToList();

            model.NewProducts = products
                .OrderByDescending(p => p.ProductID)
                .Take(20)
                .ToPagedList(pageNumber, pageSize);

            return View(model);
        }
        [ChildActionOnly]
        public ActionResult CategoriesPV()
        {
            var categories = db.Categories.ToList();
            return PartialView("_CategoriesPV", categories);
        }
        [ChildActionOnly]
        public ActionResult PersonalMenuPV()
        {
            var cart = Session["Cart"] as List<CartItem>;
            var vm = new PersonalMenuVM
            {
                IsLoggedIn = User.Identity.IsAuthenticated,
                Username = User.Identity.Name,
                CartCount = cart == null ? 0 : cart.Sum(i => i.iQuantity)
            };
            return PartialView("_PersonalMenuPV", vm);
        }
        public ActionResult ProductDetail(int? id, int? page, int quantity = 1)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var product = db.Products.Include(p => p.Category).SingleOrDefault(p => p.ProductID == id);
            if (product == null)
            {
                return HttpNotFound();
            }
            if (quantity < 1) quantity = 1;

            var vm = new ProductDetailVM
            {
                Product = product,
                Quantity = quantity,
                Total = product.ProductPrice * quantity,

                RelatedProducts = db.Products
                    .Where(p => p.CategoryID == product.CategoryID && p.ProductID != product.ProductID)
                    .Take(8)
                    .ToList(),

                TopProducts = db.Products
                    .Where(p => p.CategoryID == product.CategoryID)
                    .OrderByDescending(p => p.OrderDetails.Sum(od => (int?)od.Quantity) ?? 0)
                    .Take(8)
                    .ToPagedList(page ?? 1, 3)
            };

            return View(vm);
        }

        public ActionResult ProductList(int? categoryId, string searchTerm, string sortOrder, int? page)
        {
            var products = db.Products.Include(p => p.Category).AsQueryable();

            if (categoryId.HasValue)
            {
                products = products.Where(p => p.CategoryID == categoryId.Value);
                var cat = db.Categories.Find(categoryId.Value);
                ViewBag.CategoryName = cat != null ? cat.CategoryName : "Tat ca san pham";
            }
            else
            {
                ViewBag.CategoryName = "Tat ca san pham";
            }

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.Trim();
                products = products.Where(p =>
                    p.ProductName.Contains(searchTerm) ||
                    p.ProductDecription.Contains(searchTerm));
            }

            ViewBag.CurrentSort = sortOrder;
            ViewBag.CurrentCategory = categoryId;
            ViewBag.CurrentSearch = searchTerm;

            switch (sortOrder)
            {
                case "price_asc":
                    products = products.OrderBy(p => p.ProductPrice);
                    break;
                case "price_desc":
                    products = products.OrderByDescending(p => p.ProductPrice);
                    break;
                case "name_desc":
                    products = products.OrderByDescending(p => p.ProductName);
                    break;
                case "name_asc":
                    products = products.OrderBy(p => p.ProductName);
                    break;
                default:
                    products = products.OrderByDescending(p => p.ProductID);
                    break;
            }

            int pageNumber = page ?? 1;
            int pageSize = 9;

            var pagedProducts = products.ToPagedList(pageNumber, pageSize);
            return View(pagedProducts);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }
    }
}