﻿using System.Web.Mvc;
using System.Web.Routing;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin
{
    public class AdminAuthorizeAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Bỏ qua action con (Html.Action) để không gây lỗi redirect
            if (filterContext.IsChildAction) return;

            var session = filterContext.HttpContext.Session;
            var role = session["UserRole"] as string;

            // Cho vào nếu đăng nhập bằng bảng AdminAccount hoặc có quyền "A" (bảng User)
            bool isAdmin = session["Admin"] != null || (role != null && role.Trim() == "A");

            if (!isAdmin)
            {
                filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary(new
                    {
                        area = "",
                        controller = "Account",
                        action = "Login",
                        returnUrl = filterContext.HttpContext.Request.RawUrl
                    }));
            }

            base.OnActionExecuting(filterContext);
        }
    }
}