﻿using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class ProductsController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public ActionResult Index(string searchTerm, decimal? minPrice, decimal? maxPrice, string sortOrder, int? page)
        {
            var model = new ProductSearchVM();
            var products = db.Products.Include(p => p.Category).AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.Trim();
                products = products.Where(p => p.ProductName.Contains(searchTerm) ||
                                               p.ProductDecription.Contains(searchTerm) ||
                                               p.Category.CategoryName.Contains(searchTerm));
                model.SearchTerm = searchTerm;
            }

            if (minPrice.HasValue)
            {
                products = products.Where(p => p.ProductPrice >= minPrice.Value);
                model.MinPrice = minPrice;
            }
            if (maxPrice.HasValue)
            {
                products = products.Where(p => p.ProductPrice <= maxPrice.Value);
                model.MaxPrice = maxPrice;
            }

            switch (sortOrder)
            {
                case "name_asc":
                    products = products.OrderBy(p => p.ProductName);
                    break;
                case "name_desc":
                    products = products.OrderByDescending(p => p.ProductName);
                    break;
                case "price_asc":
                    products = products.OrderBy(p => p.ProductPrice);
                    break;
                case "price_desc":
                    products = products.OrderByDescending(p => p.ProductPrice);
                    break;
                default:
                    products = products.OrderByDescending(p => p.ProductID);
                    break;
            }
            model.SortOrder = sortOrder;

            int pageSize = 5;
            int pageNumber = (page ?? 1);
            if (pageNumber < 1) pageNumber = 1;
            model.Products = products.ToPagedList(pageNumber, pageSize);

            return View(model);
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            Product product = db.Products.Include(p => p.Category).FirstOrDefault(p => p.ProductID == id);
            if (product == null) return HttpNotFound();
            return View(product);
        }

        public ActionResult Create()
        {
            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductID,CategoryID,ProductName,ProductDecription,ProductPrice,ProductImage,UploadImg")] Product product)
        {
            // Kiểm tra định dạng & độ dài
            if (string.IsNullOrWhiteSpace(product.ProductName))
            {
                ModelState.AddModelError("ProductName", "Tên sản phẩm không được để trống!");
            }
            else if (product.ProductName.Trim().Length > 100)
            {
                ModelState.AddModelError("ProductName", "Tên sản phẩm không được vượt quá 100 ký tự!");
            }
            // Kiểm tra thêm trùng
            else if (db.Products.Any(p => p.ProductName.Trim().ToLower() == product.ProductName.Trim().ToLower()))
            {
                ModelState.AddModelError("ProductName", "Tên sản phẩm này đã tồn tại trong hệ thống!");
            }

            if (product.ProductPrice <= 0)
            {
                ModelState.AddModelError("ProductPrice", "Giá sản phẩm phải lớn hơn 0 VNĐ!");
            }

            if (product.CategoryID <= 0)
            {
                ModelState.AddModelError("CategoryID", "Vui lòng chọn danh mục cho sản phẩm!");
            }

            if (ModelState.IsValid)
            {
                product.ProductName = product.ProductName.Trim();
                if (product.UploadImg != null && product.UploadImg.ContentLength > 0)
                {
                    string fileName = Path.GetFileName(product.UploadImg.FileName);
                    string path = Path.Combine(Server.MapPath("~/Content/images/"), fileName);
                    product.UploadImg.SaveAs(path);
                    product.ProductImage = "~/Content/images/" + fileName;
                }
                else if (string.IsNullOrEmpty(product.ProductImage))
                {
                    product.ProductImage = "~/Content/images/default.png";
                }

                db.Products.Add(product);
                db.SaveChanges();
                TempData["Success"] = "Thêm sản phẩm mới thành công!";
                return RedirectToAction("Index");
            }

            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            Product product = db.Products.Find(id);
            if (product == null) return HttpNotFound();

            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProductID,CategoryID,ProductName,ProductDecription,ProductPrice,ProductImage,UploadImg")] Product product)
        {
            // Kiểm tra định dạng & độ dài
            if (string.IsNullOrWhiteSpace(product.ProductName))
            {
                ModelState.AddModelError("ProductName", "Tên sản phẩm không được để trống!");
            }
            else if (product.ProductName.Trim().Length > 100)
            {
                ModelState.AddModelError("ProductName", "Tên sản phẩm không được vượt quá 100 ký tự!");
            }
            // Kiểm tra sửa trùng
            else if (db.Products.Any(p => p.ProductID != product.ProductID && p.ProductName.Trim().ToLower() == product.ProductName.Trim().ToLower()))
            {
                ModelState.AddModelError("ProductName", "Tên sản phẩm này đã trùng với một sản phẩm khác!");
            }

            if (product.ProductPrice <= 0)
            {
                ModelState.AddModelError("ProductPrice", "Giá sản phẩm phải lớn hơn 0 VNĐ!");
            }

            if (ModelState.IsValid)
            {
                product.ProductName = product.ProductName.Trim();
                if (product.UploadImg != null && product.UploadImg.ContentLength > 0)
                {
                    string fileName = Path.GetFileName(product.UploadImg.FileName);
                    string path = Path.Combine(Server.MapPath("~/Content/images/"), fileName);
                    product.UploadImg.SaveAs(path);
                    product.ProductImage = "~/Content/images/" + fileName;
                }
                else if (string.IsNullOrEmpty(product.ProductImage))
                {
                    var oldProduct = db.Products.AsNoTracking().FirstOrDefault(p => p.ProductID == product.ProductID);
                    if (oldProduct != null)
                    {
                        product.ProductImage = oldProduct.ProductImage;
                    }
                }

                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                TempData["Success"] = "Cập nhật sản phẩm thành công!";
                return RedirectToAction("Index");
            }
            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            Product product = db.Products.Include(p => p.Category).FirstOrDefault(p => p.ProductID == id);
            if (product == null) return HttpNotFound();

            if (db.OrderDetails.Any(od => od.ProductID == id))
            {
                ViewBag.Warning = "Cảnh báo: Sản phẩm này đã có trong đơn hàng của khách. Bạn không thể xóa!";
            }

            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            // Kiểm tra ràng buộc khóa ngoại (Constraint)
            if (db.OrderDetails.Any(od => od.ProductID == id))
            {
                TempData["Error"] = "Không thể xóa sản phẩm này vì đã có trong đơn hàng của khách hàng!";
                return RedirectToAction("Index");
            }

            Product product = db.Products.Find(id);
            if (product != null)
            {
                db.Products.Remove(product);
                db.SaveChanges();
                TempData["Success"] = "Đã xóa sản phẩm thành công!";
            }
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}