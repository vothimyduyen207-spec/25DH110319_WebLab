﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class OrdersController : BaseAdminController
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public ActionResult Index(string searchTerm, string statusFilter, int? page)
        {
            var orders = db.Orders.Include(o => o.Customer).Include(o => o.OrderDetails).AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.Trim();
                orders = orders.Where(o => o.Customer.CustomerName.Contains(searchTerm) ||
                                           o.OrderID.ToString().Contains(searchTerm) ||
                                           o.AddressDelivery.Contains(searchTerm));
                ViewBag.SearchTerm = searchTerm;
            }

            if (!string.IsNullOrEmpty(statusFilter))
            {
                orders = orders.Where(o => o.PaymentStatus.Contains(statusFilter));
                ViewBag.StatusFilter = statusFilter;
            }

            orders = orders.OrderByDescending(o => o.OrderID);

            int pageSize = 10;
            int pageNumber = (page ?? 1);

            return View(orders.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Order order = db.Orders.Include(o => o.Customer)
                                   .Include(o => o.OrderDetails.Select(od => od.Product))
                                   .FirstOrDefault(o => o.OrderID == id);

            if (order == null) return HttpNotFound();

            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateStatus(int id, string orderStatus)
        {
            Order order = db.Orders.Find(id);
            if (order == null) return HttpNotFound();

            // Cập nhật trạng thái theo bảng của cô:
            // Tạo đơn: Chờ xử lý -> COD (Chưa thanh toán)
            // Chờ giao hàng -> Chờ giao hàng (Chưa thanh toán)
            // Đã giao hàng -> Đã giao hàng (Đã thanh toán)
            // Đã hủy -> Đã hủy (Chưa thanh toán)
            switch (orderStatus)
            {
                case "Chờ xử lý":
                    order.PaymentStatus = "COD (Chưa thanh toán)";
                    break;
                case "Chờ giao hàng":
                    order.PaymentStatus = "Chờ giao hàng (Chưa thanh toán)";
                    break;
                case "Đã giao hàng":
                    order.PaymentStatus = "Đã giao hàng (Đã thanh toán)";
                    break;
                case "Đã hủy":
                    order.PaymentStatus = "Đã hủy (Chưa thanh toán)";
                    break;
                default:
                    order.PaymentStatus = orderStatus;
                    break;
            }

            db.SaveChanges();
            TempData["Success"] = "Cập nhật trạng thái đơn hàng #" + id + " thành: " + orderStatus + " (" + order.PaymentStatus + ")";
            return RedirectToAction("Details", new { id });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}