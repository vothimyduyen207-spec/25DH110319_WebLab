﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class CustomersController : BaseAdminController
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public ActionResult Index(string searchTerm, int? page)
        {
            var customers = db.Customers.AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.Trim();
                customers = customers.Where(c => c.CustomerName.Contains(searchTerm) ||
                                                 c.CustomerEmail.Contains(searchTerm) ||
                                                 c.CustomerPhone.Contains(searchTerm) ||
                                                 c.Username.Contains(searchTerm));
                ViewBag.SearchTerm = searchTerm;
            }

            customers = customers.OrderBy(c => c.CustomerID);

            int pageSize = 10;
            int pageNumber = (page ?? 1);
            if (pageNumber < 1) pageNumber = 1;

            return View(customers.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Customer customer = db.Customers.Include(c => c.Orders).FirstOrDefault(c => c.CustomerID == id);
            if (customer == null) return HttpNotFound();

            return View(customer);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Customer customer = db.Customers.Include(c => c.Orders).FirstOrDefault(c => c.CustomerID == id);
            if (customer == null) return HttpNotFound();

            if (db.Orders.Any(o => o.CustomerID == id))
            {
                ViewBag.Warning = "Cảnh báo: Khách hàng này đang có đơn hàng trong hệ thống. Bạn không thể xóa!";
            }

            return View(customer);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (db.Orders.Any(o => o.CustomerID == id))
            {
                TempData["Error"] = "Không thể xóa khách hàng này vì đang có ràng buộc dữ liệu đơn hàng!";
                return RedirectToAction("Index");
            }

            Customer customer = db.Customers.Find(id);
            if (customer != null)
            {
                var user = db.Users.FirstOrDefault(u => u.Username == customer.Username);
                db.Customers.Remove(customer);
                if (user != null)
                {
                    db.Users.Remove(user);
                }
                db.SaveChanges();
                TempData["Success"] = "Đã xóa khách hàng thành công!";
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}