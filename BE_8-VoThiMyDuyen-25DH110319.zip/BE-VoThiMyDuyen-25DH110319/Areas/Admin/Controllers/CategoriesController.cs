﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class CategoriesController : BaseAdminController
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public ActionResult Index()
        {
            return View(db.Categories.ToList());
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            Category category = db.Categories.Find(id);
            if (category == null) return HttpNotFound();
            return View(category);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CategoryID,CategoryName")] Category category)
        {
            // Kiểm tra định dạng & độ dài
            if (string.IsNullOrWhiteSpace(category.CategoryName))
            {
                ModelState.AddModelError("CategoryName", "Tên danh mục không được để trống!");
            }
            else if (category.CategoryName.Trim().Length > 50)
            {
                ModelState.AddModelError("CategoryName", "Tên danh mục không được vượt quá 50 ký tự!");
            }
            // Kiểm tra thêm trùng
            else if (db.Categories.Any(c => c.CategoryName.Trim().ToLower() == category.CategoryName.Trim().ToLower()))
            {
                ModelState.AddModelError("CategoryName", "Tên danh mục này đã tồn tại trong hệ thống!");
            }

            if (ModelState.IsValid)
            {
                category.CategoryName = category.CategoryName.Trim();
                db.Categories.Add(category);
                db.SaveChanges();
                TempData["Success"] = "Thêm danh mục mới thành công!";
                return RedirectToAction("Index");
            }
            return View(category);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            Category category = db.Categories.Find(id);
            if (category == null) return HttpNotFound();
            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CategoryID,CategoryName")] Category category)
        {
            // Kiểm tra định dạng & độ dài
            if (string.IsNullOrWhiteSpace(category.CategoryName))
            {
                ModelState.AddModelError("CategoryName", "Tên danh mục không được để trống!");
            }
            else if (category.CategoryName.Trim().Length > 50)
            {
                ModelState.AddModelError("CategoryName", "Tên danh mục không được vượt quá 50 ký tự!");
            }
            // Kiểm tra sửa trùng
            else if (db.Categories.Any(c => c.CategoryID != category.CategoryID && c.CategoryName.Trim().ToLower() == category.CategoryName.Trim().ToLower()))
            {
                ModelState.AddModelError("CategoryName", "Tên danh mục này đã trùng với một danh mục khác!");
            }

            if (ModelState.IsValid)
            {
                category.CategoryName = category.CategoryName.Trim();
                db.Entry(category).State = EntityState.Modified;
                db.SaveChanges();
                TempData["Success"] = "Cập nhật danh mục thành công!";
                return RedirectToAction("Index");
            }
            return View(category);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            Category category = db.Categories.Find(id);
            if (category == null) return HttpNotFound();

            if (db.Products.Any(p => p.CategoryID == id))
            {
                ViewBag.Warning = "Cảnh báo: Danh mục này đang có sản phẩm thuộc về nó. Bạn không thể xóa!";
            }

            return View(category);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            // Kiểm tra ràng buộc khóa ngoại (Constraint)
            if (db.Products.Any(p => p.CategoryID == id))
            {
                TempData["Error"] = "Không thể xóa danh mục này vì đang có sản phẩm thuộc danh mục!";
                return RedirectToAction("Index");
            }

            Category category = db.Categories.Find(id);
            if (category != null)
            {
                db.Categories.Remove(category);
                db.SaveChanges();
                TempData["Success"] = "Đã xóa danh mục thành công!";
            }
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}