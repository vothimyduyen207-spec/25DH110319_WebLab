﻿using System.Linq;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class HomeController : BaseAdminController
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public ActionResult Index()
        {
            ViewBag.TotalProducts = db.Products.Count();
            ViewBag.TotalCategories = db.Categories.Count();
            ViewBag.TotalOrders = db.Orders.Count();
            ViewBag.TotalCustomers = db.Customers.Count();
            ViewBag.TotalRevenue = db.Orders.Sum(o => (decimal?)o.TotalAmount) ?? 0;
            ViewBag.RecentOrders = db.Orders.OrderByDescending(o => o.OrderID).Take(5).ToList();

            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}