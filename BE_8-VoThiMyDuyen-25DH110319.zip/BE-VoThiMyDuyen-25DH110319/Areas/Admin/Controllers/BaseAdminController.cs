﻿using System.Web.Mvc;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    [AdminAuthorize]
    public class BaseAdminController : Controller { }
}