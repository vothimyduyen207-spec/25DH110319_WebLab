﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _25DH110319_Lab01c.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Lab03_Home() { return View(); }
        public ActionResult Login() { return View(); }
        public ActionResult Repass() { return View(); }
        public ActionResult Regist() { return View(); }
        public ActionResult RegistNangCao() { return View(); }
    }
}