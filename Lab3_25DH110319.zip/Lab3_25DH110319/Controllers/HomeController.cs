﻿using System.Web.Mvc;

namespace Lab3_25DH110319.Controllers
{
    public class HomeController : Controller
    {
        // Route mặc định (Index) chạy thẳng file Lab3_VD1
        public ActionResult Index()
        {
            return View("~/Views/Lab3_VD1.cshtml");
        }

        // Hoặc tạo một Action riêng mang tên Lab3_VD1
        public ActionResult Lab3_VD1()
        {
            return View(); 
        }
        public ActionResult Lab3_VD2()
        {
            return View();
        }
        public ActionResult Lab3_VD3()
        {
            return View();
        }
        public ActionResult Lab3_VD4()
        {
            return View();
        }
        public ActionResult Lab3_VD5()
        {
            return View();
        }
        public ActionResult Lab3_VD6()
        {
            return View();
        }
        public ActionResult Lab3_VD7()
        {
            return View();
        }
        public ActionResult Lab3_VD8()
        {
            return View();
        }
        public ActionResult Lab3_VD9()
        {
            return View();
        }
        public ActionResult Lab3_VD10()
        {
            return View();
        }
        public ActionResult Lab3_BT1()
        {
            return View();
        }
        public ActionResult Lab3()
        {
            return View();
        }
    }
}
