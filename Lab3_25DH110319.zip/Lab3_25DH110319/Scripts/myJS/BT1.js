﻿function chonChuyenNganh() {
    var nganh = document.getElementsByName("chuyennganh");
    var sotruongInput = document.getElementById("sotruong");

    for (var i = 0; i < nganh.length; i++) {
        if (nganh[i].checked) {
            if (nganh[i].value === "Hệ thống") {
                sotruongInput.value = "Phân tích & Thiết kế";
            } else if (nganh[i].value === "Phần mềm") {
                sotruongInput.value = "Lập trình";
            } else if (nganh[i].value === "Mạng máy tính") {
                sotruongInput.value = "Quản lý mạng";
            }
        }
    }
}

function dangKy() {
    var valid = true;

    // 1. Mã SV (đúng 10 ký tự)
    var masv = document.getElementById("masv").value.trim();
    if (masv.length !== 10) {
        document.getElementById("err_masv").innerText = "Mã sinh viên gồm 10 ký tự";
        valid = false;
    } else {
        document.getElementById("err_masv").innerText = "";
    }

    // 2. Họ tên (không rỗng, < 30 ký tự)
    var hoten = document.getElementById("hoten").value.trim();
    if (hoten === "" || hoten.length >= 30) {
        document.getElementById("err_hoten").innerText = "Họ tên không rỗng và < 30 ký tự";
        valid = false;
    } else {
        document.getElementById("err_hoten").innerText = "";
    }

    // 3. Tuổi (>= 18)
    var tuoi = parseInt(document.getElementById("tuoi").value);
    if (isNaN(tuoi) || tuoi < 18) {
        document.getElementById("err_tuoi").innerText = "Tuổi phải 18 trở lên";
        valid = false;
    } else {
        document.getElementById("err_tuoi").innerText = "";
    }

    // Ngoại ngữ đã chọn
    var ngoaingu = document.getElementsByName("ngoaingu");
    var listNN = [];
    for (var i = 0; i < ngoaingu.length; i++) {
        if (ngoaingu[i].checked) listNN.push(ngoaingu[i].value);
    }
    document.getElementById("res_ngoaingu").innerText = listNN.length > 0 ? listNN.join(" và ") : "Không chọn";

    // Thông báo chung
    var status = document.getElementById("status");
    if (valid) {
        status.style.color = "green";
        status.innerText = "Bạn đã đăng ký thành công";
    } else {
        status.style.color = "red";
        status.innerText = "Bạn phải nhập lại cho đúng";
    }
}