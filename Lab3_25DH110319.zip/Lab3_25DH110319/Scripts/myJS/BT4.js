﻿function addTask() {
    var input = document.getElementById("taskInput");
    var val = input.value.trim();
    if (val === "") {
        alert("Vui lòng nhập công việc!");
        return;
    }

    var ul = document.getElementById("taskList");
    var li = document.createElement("li");

    li.innerHTML = '<input type="checkbox" onclick="toggleTask(this)"> <span>' + val + '</span> <button class="delete-btn" onclick="removeTask(this)">Xóa</button>';

    ul.appendChild(li);
    input.value = "";
}

function toggleTask(chk) {
    var span = chk.nextElementSibling;
    if (chk.checked) {
        span.style.textDecoration = "line-through";
        span.style.color = "gray";
    } else {
        span.style.textDecoration = "none";
        span.style.color = "black";
    }
}

function removeTask(btn) {
    var li = btn.parentElement;
    li.remove();
}