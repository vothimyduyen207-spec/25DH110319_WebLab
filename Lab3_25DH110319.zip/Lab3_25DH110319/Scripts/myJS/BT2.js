﻿// 1. Kiểm tra rỗng chung
function checkEmpty(id, fieldName) {
    var val = document.getElementById(id).value.trim();
    var errSpan = document.getElementById("err_" + id);
    if (val === "") {
        errSpan.innerText = "Vui lòng nhập " + fieldName;
        return false;
    } else {
        errSpan.innerText = "";
        return true;
    }
}

// 2. Kiểm tra SĐT >= 10 số
function checkPhone() {
    var phone = document.getElementById("phone").value.trim();
    var errSpan = document.getElementById("err_phone");
    var regex = /^[0-9]{10,}$/;
    if (!regex.test(phone)) {
        errSpan.innerText = "Số điện thoại phải từ 10 chữ số trở lên";
        return false;
    } else {
        errSpan.innerText = "";
        return true;
    }
}

// 3. Hàm dùng chung cho nút Văn phòng & Nhà riêng
function chonDiaChi(loai) {
    if (loai === 'vanphong') {
        alert("Bạn chọn giao hàng tại văn phòng");
    } else if (loai === 'nharieng') {
        alert("Bạn chọn giao hàng tại nhà riêng");
    }
}

// 4. Xử lý nút Lưu
function luuThongTin() {
    var validTen = checkEmpty('ten', 'Tên');
    var validDiaChi = checkEmpty('diachi', 'Địa chỉ');
    var validTinh = checkEmpty('tinh', 'Tỉnh/thành phố');
    var validQuan = checkEmpty('quan', 'Quận/huyện');
    var validPhuong = checkEmpty('phuong', 'Phường/xã');
    var validPhone = checkPhone();

    if (validTen && validDiaChi && validTinh && validQuan && validPhuong && validPhone) {
        alert("Lưu thông tin thành công");
    } else {
        alert("Thông tin nhập không hợp lệ");
    }
}