﻿function startProgress() {
    var elem = document.getElementById("myBar");
    var label = document.getElementById("label");
    var width = 0;

    var id = setInterval(frame, 50); // Tăng tiến trình sau mỗi 50ms

    function frame() {
        if (width >= 100) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + "%";
            label.innerText = width + "%";
        }
    }
}