﻿using System.Web;
using System.Web.Mvc;

namespace Lab3_25DH110319
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
