﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class OrdersController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

     
        public ActionResult Index(string searchTerm, int? page)
        {
            var orders = db.Orders.Include(o => o.Customer).AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                orders = orders.Where(o => o.Customer.CustomerName.Contains(searchTerm) ||
                                           o.OrderID.ToString().Contains(searchTerm));
                ViewBag.SearchTerm = searchTerm;
            }

            orders = orders.OrderByDescending(o => o.OrderID);

            int pageSize = 10;
            int pageNumber = (page ?? 1);

            return View(orders.ToPagedList(pageNumber, pageSize));
        }

  
        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Order order = db.Orders.Include(o => o.Customer)
                                   .Include(o => o.OrderDetails.Select(od => od.Product))
                                   .FirstOrDefault(o => o.OrderID == id);

            if (order == null) return HttpNotFound();

            return View(order);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}