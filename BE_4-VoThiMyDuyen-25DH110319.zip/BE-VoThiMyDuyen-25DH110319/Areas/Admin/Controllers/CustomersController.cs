﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Areas.Admin.Controllers
{
    public class CustomersController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        
        public ActionResult Index(string searchTerm, int? page)
        {
            var customers = db.Customers.AsQueryable();

           
            if (!string.IsNullOrEmpty(searchTerm))
            {
                customers = customers.Where(c => c.CustomerName.Contains(searchTerm) ||
                                                 c.CustomerEmail.Contains(searchTerm) ||
                                                 c.CustomerPhone.Contains(searchTerm));
                ViewBag.SearchTerm = searchTerm;
            }

            customers = customers.OrderBy(c => c.CustomerID);

            int pageSize = 10;
            int pageNumber = (page ?? 1);

            return View(customers.ToPagedList(pageNumber, pageSize));
        }

        
        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            Customer customer = db.Customers.Find(id);
            if (customer == null) return HttpNotFound();

            return View(customer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}