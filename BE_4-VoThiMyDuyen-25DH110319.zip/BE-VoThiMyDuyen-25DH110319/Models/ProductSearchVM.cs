﻿using PagedList;

namespace BE_VoThiMyDuyen_25DH110319.Models
{
    public class ProductSearchVM
    {
        public string SearchTerm { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string SortOrder { get; set; }
        public IPagedList<Product> Products { get; set; }
    }
}