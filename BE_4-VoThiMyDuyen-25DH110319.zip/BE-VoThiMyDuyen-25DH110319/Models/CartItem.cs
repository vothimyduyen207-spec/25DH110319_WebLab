﻿using System;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Models
{
    public class CartItem
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

        public int iProductID { get; set; }
        public string sProductName { get; set; }
        public string sProductImage { get; set; }
        public decimal dPrice { get; set; }
        public int iQuantity { get; set; }
        public decimal dTotalPrice
        {
            get { return iQuantity * dPrice; }
        }

        
        public CartItem(int productID)
        {
            iProductID = productID;
            Product product = db.Products.Find(productID);
            if (product != null)
            {
                sProductName = product.ProductName;
                sProductImage = product.ProductImage;
                dPrice = product.ProductPrice;
                iQuantity = 1;
            }
        }
    }
}