﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Models;

namespace BE_VoThiMyDuyen_25DH110319.Controllers
{
    public class CartController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();

      
        public List<CartItem> GetCart()
        {
            List<CartItem> myCart = Session["Cart"] as List<CartItem>;
            if (myCart == null)
            {
                myCart = new List<CartItem>();
                Session["Cart"] = myCart;
            }
            return myCart;
        }

       
        public ActionResult AddToCart(int id, string strURL)
        {
            List<CartItem> myCart = GetCart();
            CartItem item = myCart.Find(p => p.iProductID == id);

            if (item == null)
            {
                item = new CartItem(id);
                myCart.Add(item);
            }
            else
            {
                item.iQuantity++;
            }

            return Redirect(strURL);
        }

        
        private int TotalQuantity()
        {
            List<CartItem> myCart = Session["Cart"] as List<CartItem>;
            if (myCart == null) return 0;
            return myCart.Sum(p => p.iQuantity);
        }

        private decimal TotalPrice()
        {
            List<CartItem> myCart = Session["Cart"] as List<CartItem>;
            if (myCart == null) return 0;
            return myCart.Sum(p => p.dTotalPrice);
        }

       
        public ActionResult Index()
        {
            List<CartItem> myCart = GetCart();
            if (myCart.Count == 0)
            {
                ViewBag.Notification = "Giỏ hàng của bạn đang trống!";
            }

            ViewBag.TotalQuantity = TotalQuantity();
            ViewBag.TotalPrice = TotalPrice();

            return View(myCart);
        }

     
        public ActionResult RemoveCartItem(int id)
        {
            List<CartItem> myCart = GetCart();
            CartItem item = myCart.SingleOrDefault(n => n.iProductID == id);
            if (item != null)
            {
                myCart.RemoveAll(n => n.iProductID == id);
            }
            return RedirectToAction("Index");
        }

       
        public ActionResult UpdateCart(int id, FormCollection form)
        {
            List<CartItem> myCart = GetCart();
            CartItem item = myCart.SingleOrDefault(n => n.iProductID == id);
            if (item != null)
            {
                item.iQuantity = int.Parse(form["txtQuantity"].ToString());
            }
            return RedirectToAction("Index");
        }

       
        public ActionResult CartPartial()
        {
            ViewBag.TotalQuantity = TotalQuantity();
            return PartialView();
        }
        
        public ActionResult Checkout()
        {
           
            List<CartItem> myCart = GetCart();
            if (myCart == null || myCart.Count == 0)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.TotalQuantity = TotalQuantity();
            ViewBag.TotalPrice = TotalPrice();

            return View(myCart);
        }

       
        [HttpPost]
        public ActionResult Checkout(FormCollection form)
        {
            try
            {
                List<CartItem> myCart = GetCart();
                if (myCart == null || myCart.Count == 0)
                {
                    return RedirectToAction("Index", "Home");
                }

                
                Order order = new Order();
                order.OrderDate = DateTime.Now;
                order.AddressDelivery = form["AddressDelivery"];

                
                if (Session["Customer"] != null)
                {
                    Customer customer = (Customer)Session["Customer"];
                    order.CustomerID = customer.CustomerID;
                }

                db.Orders.Add(order);
                db.SaveChanges();

               
                foreach (var item in myCart)
                {
                    OrderDetail detail = new OrderDetail();
                    detail.OrderID = order.OrderID;
                    detail.ProductID = item.iProductID;
                    detail.Quantity = item.iQuantity;
                    detail.UnitPrice = item.dPrice;

                    db.OrderDetails.Add(detail);
                }
                db.SaveChanges();

                Session["Cart"] = null;

                return RedirectToAction("OrderSuccess");
            }
            catch
            {
                ViewBag.Error = "Có lỗi xảy ra trong quá trình xử lý đơn hàng. Vui lòng thử lại!";
                return View(GetCart());
            }
        }

      
        public ActionResult OrderSuccess()
        {
            return View();
        }
    }
}