﻿using System.Linq;
using System.Web.Mvc;
using BE_VoThiMyDuyen_25DH110319.Models;
using PagedList;

namespace BE_VoThiMyDuyen_25DH110319.Controllers
{
    public class HomeController : Controller
    {
        private MyStoreEntities1 db = new MyStoreEntities1();


        public ActionResult Index(string searchTerm, int? page)
        {

            var products = db.Products.AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {

                products = products.Where(p => p.ProductName.Contains(searchTerm));
                ViewBag.SearchTerm = searchTerm;
            }


            int pageNumber = (page ?? 1);
            int pageSize = 6;


            products = products.OrderBy(p => p.ProductID);


            return View(products.ToPagedList(pageNumber, pageSize));
        }
    }
}

      