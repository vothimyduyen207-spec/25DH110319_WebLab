﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _25DH110319_Lab01b.Controllers
{
    using System.Web.Mvc;

    namespace _25DH110319_Lab01a.Controllers
    {
        public class HomeController : Controller
        {
            // Trang mặc định
            public ActionResult Index()
            {
                return View();
            }

            // Bài 1: Chuyển trang (home, intro, new, contact)
            public ActionResult Lab01b_BaiTap1()
            {
                return View();
            }

            public ActionResult intro()
            {
                return View();
            }

            public ActionResult newpage()
            {
                return View();
            }

            public ActionResult contact()
            {
                return View();
            }

            // Bài 2: Bảng gộp ô (colspan, rowspan)
            public ActionResult Lab01b_BaiTap2()
            {
                return View();
            }

         

            // Bài 3: Bảng thông tin sinh viên
            public ActionResult Lab01b_BaiTap3()
            {
                return View();
            }

            // Bài 4: Bố cục tin tức (Table)
            public ActionResult Lab01b_BaiTap4()
            {
                return View();
            }

            // Bài 5: Bố cục Portfolio (Table + Màu nền)
            public ActionResult Lab01b_BaiTap5()
            {
                return View();
            }
        }
    }
}